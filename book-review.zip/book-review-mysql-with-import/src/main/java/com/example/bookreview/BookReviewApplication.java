package com.example.bookreview;

import com.example.bookreview.service.BookImportService;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class BookReviewApplication {
    public static void main(String[] args) {
        SpringApplication.run(BookReviewApplication.class, args);
    }

    @Bean
    CommandLineRunner run(BookImportService service) {
        return args -> service.importBooks("java programming");
    }
}

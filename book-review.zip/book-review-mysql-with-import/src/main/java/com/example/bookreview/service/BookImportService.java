package com.example.bookreview.service;

import com.example.bookreview.entity.Book;
import com.example.bookreview.repository.BookRepository;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.http.ResponseEntity;

import java.util.List;
import java.util.Map;

@Service
public class BookImportService {
    private final BookRepository repo;

    public BookImportService(BookRepository repo) {
        this.repo = repo;
    }

    public void importBooks(String keyword) {
        String url = "https://openlibrary.org/search.json?q=" + keyword.replace(" ", "+");
        RestTemplate restTemplate = new RestTemplate();
        ResponseEntity<Map> response = restTemplate.getForEntity(url, Map.class);
        List<Map<String, Object>> docs = (List<Map<String, Object>>) response.getBody().get("docs");

        int count = 0;
        for (Map<String, Object> bookData : docs) {
            if (count >= 20) break;
            String title = (String) bookData.get("title");
            List<String> authors = (List<String>) bookData.get("author_name");
            String author = (authors != null && !authors.isEmpty()) ? authors.get(0) : "Unknown";
            String description = "Imported from Open Library.";
            repo.save(new Book(title, author, description));
            count++;
        }
    }
}

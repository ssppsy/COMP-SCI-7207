package com.example.bookreview.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import com.example.bookreview.entity.Book;

public interface BookRepository extends JpaRepository<Book, Long> {
    List<Book> findByTitleContainingIgnoreCase(String keyword);  // 按标题模糊搜索
}


package com.example.bookreview.controller;

import com.example.bookreview.entity.Book;
import com.example.bookreview.repository.BookRepository;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
public class BookController {

    private final BookRepository bookRepo;

    public BookController(BookRepository bookRepo) {
        this.bookRepo = bookRepo;
    }

    @GetMapping("/")
    public String index(Model model) {
        model.addAttribute("books", bookRepo.findAll());
        return "index";
    }

    @GetMapping("/book/{id}")
    public String viewBook(@PathVariable Long id, Model model) {
        model.addAttribute("book", bookRepo.findById(id).orElse(null));
        return "view";
    }

    @GetMapping("/search")
    public String searchBooks(@RequestParam("keyword") String keyword, Model model) {
        List<Book> books = bookRepo.findByTitleContainingIgnoreCase(keyword);
        model.addAttribute("books", books);
        model.addAttribute("keyword", keyword);
        return "search-result"; // 对应 templates/search-results.html
    }
}
